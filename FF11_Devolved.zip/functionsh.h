// in functions header

class Functions
{
      public:
             int level_up(int& a, int& d, int& e, int& m, int& hp);
             char explore();
             int boss_Battle();
             int customize();
};
